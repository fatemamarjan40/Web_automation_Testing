package batch7project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/");
		//driver.navigate().to("https://www.saucedemo.com/v1/");
		//maximize the window
		driver.manage().window().maximize();
		//driver.close();
		//driver.quit()
		//quit vs close interview
		 
		//Thread.sleep(5000);// milisecond 50000 eita use na kora better implicite ta use korbo
		
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		driver.findElement(By.id("user-name")).sendKeys("standard_user");
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		driver.findElement(By.id("login-button")).click();
		//driver.findElement(By.className("product_sort_container")).click();
		driver.findElement(By.className("btn_primary")).click();
		driver.findElement(By.className("shopping_cart_link")).click();
		driver.findElement(By.className("btn_action")).click();
		driver.findElement(By.id("first-name")).sendKeys("abc");
		driver.findElement(By.id("last-name")).sendKeys("xyz");
		driver.findElement(By.id("postal-code")).sendKeys("1205");
		driver.findElement(By.className("btn_primary")).click();
		driver.findElement(By.className("btn_action")).click();
		driver.findElement(By.className("bm-burger-button")).click();
		driver.findElement(By.id("logout_sidebar_link")).click();
		
	driver.close();
		

	}

}
