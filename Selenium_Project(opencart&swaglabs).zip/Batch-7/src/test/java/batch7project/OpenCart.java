package batch7project;

import java.util.List;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class OpenCart {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.opencart.com/?fbclid=IwAR2XCSFS2r-63zT_a9ahiE3I1BNW3GVBN7SjgFy6WWZk3HXxJ5aDtUUBCD8");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//span[normalize-space()='My Account']")).click();
		driver.findElement(By.xpath("//a[normalize-space()='Register']")).click();
		driver.findElement(By.id("input-firstname")).sendKeys("abc");
		driver.findElement(By.id("input-lastname")).sendKeys("xyz");
		driver.findElement(By.cssSelector("input#input-email")).sendKeys("abc@gmail.com");
		driver.findElement(By.cssSelector("input#input-password")).sendKeys("#1234%");
	
	  
		
		//Thread.sleep(5000);
	//WebElement radiobutton1 = driver.findElement(By.id("input-newsletter-yes"));
		//WebElement radiobutton2 = driver.findElement(By.id("input-newsletter-no"));
	//radiobutton1.click();
	//	Thread.sleep(3000);
		//radiobutton2.click();
		
		//WebElement checkbox = driver.findElement(By.xpath("//input[@name='agree']"));						
       		//checkbox.click (); 			
          //System.out.println(checkbox.isSelected());	
         
		 driver.findElement(By.className("btn")).click();
	     Thread.sleep(1000);
	     
	     driver.findElement(By.xpath("//span[normalize-space()='My Account']")).click();
			driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Login']")).click();
			driver.findElement(By.cssSelector("input#input-email")).sendKeys("abc@gmail.com");
			driver.findElement(By.id("input-password")).sendKeys("#1234%");
			 driver.findElement(By.className("btn")).click();
			 driver.findElement(By.cssSelector("input#input-search")).sendKeys("phone");
			 driver.findElement(By.id("input-description")).click();
			 Thread.sleep(1000);
			 WebElement dropdown = driver.findElement(By.id("input-category"));
				Select selectobject = new Select(dropdown);
				selectobject.selectByIndex(1);
				selectobject.selectByVisibleText("Desktops");
				//selectobject.selectByVisibleText("PC");
				selectobject.selectByVisibleText("Phones & PDAs");
				selectobject.selectByVisibleText("Cameras");
				driver.findElement(By.id("input-sub-category")).click();
				 driver.findElement(By.id("button-search")).click();
				 
				 driver.close();
		
	}
}
