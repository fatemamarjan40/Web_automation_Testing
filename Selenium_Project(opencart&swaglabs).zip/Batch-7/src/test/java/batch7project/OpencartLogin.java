package batch7project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class OpencartLogin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				WebDriverManager.chromedriver().setup();
				WebDriver driver = new ChromeDriver();
				driver.get("https://demo.opencart.com/?fbclid=IwAR2XCSFS2r-63zT_a9ahiE3I1BNW3GVBN7SjgFy6WWZk3HXxJ5aDtUUBCD8");
				driver.manage().window().maximize();
				driver.findElement(By.xpath("//span[normalize-space()='My Account']")).click();
				driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Login']")).click();
				driver.findElement(By.cssSelector("input#input-email")).sendKeys("abc@gmail.com");
				driver.findElement(By.id("input-password")).sendKeys("#1234%");
				 driver.findElement(By.className("btn")).click();
				 driver.findElement(By.cssSelector("input#input-search")).sendKeys("phone");
				 driver.findElement(By.id("input-description")).click();
				 
				 WebElement dropdown = driver.findElement(By.id("input-category"));
					Select selectobject = new Select(dropdown);
					selectobject.selectByIndex(1);
					selectobject.selectByVisibleText("Desktops");
					//selectobject.selectByVisibleText("PC");
					selectobject.selectByVisibleText("Phones & PDAs");
					selectobject.selectByVisibleText("Cameras");
					driver.findElement(By.id("input-sub-category")).click();
					 driver.findElement(By.id("button-search")).click();
//driver.close();
					//<input type="checkbox" name="sub_category" value="1" id="input-sub-category" class="form-check-input">
	}

}
